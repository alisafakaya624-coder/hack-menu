#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include "imgui.h"
#include "backends/imgui_impl_glfw.h"
#include "backends/imgui_impl_opengl3.h"
#include <cmath>
#include <iostream>
#include <algorithm>

extern "C" {
    __attribute__((visibility("default"))) void RunHellfireMenu();
}

const char* vertexShaderSource = R"(
#version 330 core
layout (location = 0) in vec2 aPos;
void main() {
    gl_Position = vec4(aPos.x, aPos.y, 0.0, 1.0);
}
)";

const char* fragmentShaderSource = R"(
#version 330 core
out vec4 FragColor;
uniform float u_time;
uniform vec2 u_resolution;
uniform vec2 u_rect_pos;
uniform vec2 u_rect_size;
uniform float u_intensity;

float hash(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

float noise(vec2 x) {
    vec2 p = floor(x);
    vec2 f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(p + vec2(0.0, 0.0)), hash(p + vec2(1.0, 0.0)), f.x),
               mix(hash(p + vec2(0.0, 1.0)), hash(p + vec2(1.0, 1.0)), f.x), f.y);
}

float sdBox(vec2 p, vec2 b) {
    vec2 d = abs(p) - b;
    return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0);
}

void main() {
    vec2 fragCoord = gl_FragCoord.xy;
    vec2 rectCenter = vec2(u_rect_pos.x + u_rect_size.x * 0.5, (u_resolution.y - u_rect_pos.y) - u_rect_size.y * 0.5);
    vec2 p = fragCoord - rectCenter;
    vec2 boxSize = u_rect_size * 0.5;
    
    float dist = sdBox(p, boxSize);
    
    if (dist < -5.0) {
        FragColor = vec4(0.0);
        return;
    }
    
    float t = u_time * 2.0;
    vec2 uv = p / max(u_rect_size.x, u_rect_size.y);
    vec2 noise_uv = uv * 10.0;
    vec2 dir = normalize(p);
    noise_uv -= dir * t * 1.5;
    
    float f = 0.5000 * noise(noise_uv * 1.5);
    f += 0.2500 * noise(noise_uv * 3.0);
    f += 0.1250 * noise(noise_uv * 6.0);
    f = pow(f, 2.0);
    
    float flameThickness = 10.0 + (30.0 * u_intensity);
    float borderMask = 1.0 - clamp(abs(dist) / flameThickness, 0.0, 1.0);
    borderMask = pow(borderMask, 2.0);
    
    float fireAlpha = f * borderMask * (0.3 + 0.7 * u_intensity) * 3.0;
    
    vec3 colorHigh = vec3(1.0, 0.6, 0.1);
    vec3 colorLow = vec3(0.8, 0.2, 0.0);
    vec3 color = mix(colorLow, colorHigh, u_intensity) * (f * 2.5);
    
    float core = 1.0 - clamp(abs(dist) / 3.0, 0.0, 1.0);
    color += vec3(1.0, 0.9, 0.6) * core * u_intensity;

    FragColor = vec4(color * fireAlpha, fireAlpha);
}
)";

GLuint CompileShader(GLenum type, const char* source) {
    GLuint shader = glCreateShader(type);
    glShaderSource(shader, 1, &source, NULL);
    glCompileShader(shader);
    int success;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if (!success) {
        char infoLog[512];
        glGetShaderInfoLog(shader, 512, NULL, infoLog);
        std::cerr << "Shader Error: " << infoLog << std::endl;
    }
    return shader;
}

void RunHellfireMenu() {
    if (!glfwInit()) return;
    
    glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, GLFW_TRUE);
    glfwWindowHint(GLFW_DECORATED, GLFW_FALSE);
    glfwWindowHint(GLFW_FLOATING, GLFW_TRUE);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWmonitor* monitor = glfwGetPrimaryMonitor();
    const GLFWvidmode* mode = glfwGetVideoMode(monitor);
    GLFWwindow* window = glfwCreateWindow(mode->width, mode->height, "Hellfire", NULL, NULL);
    
    glfwMakeContextCurrent(window);
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) return;

    GLuint vertexShader = CompileShader(GL_VERTEX_SHADER, vertexShaderSource);
    GLuint fragmentShader = CompileShader(GL_FRAGMENT_SHADER, fragmentShaderSource);
    GLuint shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);

    float vertices[] = { -1.f, 1.f, -1.f, -1.f, 1.f, -1.f, -1.f, 1.f, 1.f, -1.f, 1.f, 1.f };
    GLuint VBO, VAO;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    ImGui::StyleColorsDark();
    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init("#version 330");

    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding = 12.0f;
    style.ChildRounding = 8.0f;
    style.FrameRounding = 6.0f;
    style.WindowPadding = ImVec2(16, 16);
    style.FramePadding = ImVec2(12, 8);
    style.ItemSpacing = ImVec2(12, 12);
    
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.08f, 0.08f, 0.09f, 0.95f);
    style.Colors[ImGuiCol_Border] = ImVec4(0.2f, 0.2f, 0.22f, 0.5f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.12f, 0.12f, 0.14f, 1.0f);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.16f, 0.16f, 0.19f, 1.0f);
    style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.20f, 0.20f, 0.24f, 1.0f);
    style.Colors[ImGuiCol_Button] = ImVec4(0.12f, 0.12f, 0.14f, 1.0f);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.9f, 0.3f, 0.05f, 1.0f);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(1.0f, 0.4f, 0.1f, 1.0f);
    style.Colors[ImGuiCol_CheckMark] = ImVec4(1.0f, 0.4f, 0.1f, 1.0f);

    float start_time = glfwGetTime();
    int active_tab = 0;
    float tab_anim[3] = {1.0f, 0.0f, 0.0f};

    ImVec2 menu_pos = ImVec2(300, 300);
    ImVec2 menu_size = ImVec2(700, 450);
    bool is_dragging = false;

    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();
        
        int w, h;
        glfwGetFramebufferSize(window, &w, &h);
        glViewport(0, 0, w, h);
        
        glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        float current_time = glfwGetTime();
        float elapsed = current_time - start_time;
        float intensity = 1.0f;
        if (elapsed > 2.0f) {
            float decay = (elapsed - 2.0f);
            intensity = std::max(0.15f, 1.0f - (decay * 1.5f));
        }

        // Passthrough logic: if mouse is not over the menu (including fire padding), make window click-through
        double mx, my;
        glfwGetCursorPos(window, &mx, &my);
        float pad = 40.0f; // fire padding
        bool over_menu = (mx >= menu_pos.x - pad && mx <= menu_pos.x + menu_size.x + pad &&
                          my >= menu_pos.y - pad && my <= menu_pos.y + menu_size.y + pad);
        
        // If we are actively dragging, we don't want to lose focus
        static bool current_passthrough = false;
        bool target_passthrough = !(over_menu || is_dragging);
        if (current_passthrough != target_passthrough) {
            glfwSetWindowAttrib(window, GLFW_MOUSE_PASSTHROUGH, target_passthrough ? GLFW_TRUE : GLFW_FALSE);
            current_passthrough = target_passthrough;
        }

        glUseProgram(shaderProgram);
        glUniform1f(glGetUniformLocation(shaderProgram, "u_time"), current_time);
        glUniform2f(glGetUniformLocation(shaderProgram, "u_resolution"), (float)w, (float)h);
        glUniform2f(glGetUniformLocation(shaderProgram, "u_rect_pos"), menu_pos.x, menu_pos.y);
        glUniform2f(glGetUniformLocation(shaderProgram, "u_rect_size"), menu_size.x, menu_size.y);
        glUniform1f(glGetUniformLocation(shaderProgram, "u_intensity"), intensity);
        
        glBindVertexArray(VAO);
        glDrawArrays(GL_TRIANGLES, 0, 6);

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        ImGui::SetNextWindowPos(menu_pos, ImGuiCond_Always);
        ImGui::SetNextWindowSize(menu_size, ImGuiCond_Always);
        
        ImGui::Begin("Hellfire Menu", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize);

        // Explicit Drag Zone (top header)
        ImGui::SetCursorPos(ImVec2(0, 0));
        ImGui::InvisibleButton("##DragZone", ImVec2(menu_size.x, 60)); // Top 60 pixels
        if (ImGui::IsItemActive()) {
            is_dragging = true;
            menu_pos.x += io.MouseDelta.x;
            menu_pos.y += io.MouseDelta.y;
        } else {
            is_dragging = false;
        }

        // Draw header text
        ImGui::SetCursorPos(ImVec2(16, 16));
        ImGui::TextColored(ImVec4(1.0f, 0.4f, 0.1f, 1.0f), "HELLFIRE");
        ImGui::SameLine();
        ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "v4080");
        ImGui::Spacing();
        
        // Tabs
        const char* tabs[] = { "AIM", "VISUALS", "MISC" };
        ImGui::BeginGroup();
        for (int i = 0; i < 3; i++) {
            tab_anim[i] += ((active_tab == i ? 1.0f : 0.0f) - tab_anim[i]) * 0.15f;
            ImVec4 tab_color = ImVec4(0.2f + 0.7f * tab_anim[i], 0.2f + 0.2f * tab_anim[i], 0.2f + -0.1f * tab_anim[i], 1.0f);
            
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.1f, 0.1f, 0.12f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_Text, tab_color);
            if (ImGui::Button(tabs[i], ImVec2(120, 35))) active_tab = i;
            ImGui::PopStyleColor(2);
            
            if (tab_anim[i] > 0.01f) {
                ImVec2 p_min = ImGui::GetItemRectMin();
                ImVec2 p_max = ImGui::GetItemRectMax();
                p_min.y = p_max.y - 2;
                float center_x = (p_min.x + p_max.x) * 0.5f;
                float width = (p_max.x - p_min.x) * tab_anim[i];
                p_min.x = center_x - width * 0.5f;
                p_max.x = center_x + width * 0.5f;
                ImGui::GetWindowDrawList()->AddRectFilled(p_min, p_max, ImColor(1.0f, 0.4f, 0.1f, 1.0f));
            }
            ImGui::SameLine();
        }
        ImGui::EndGroup();
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::BeginChild("Content", ImVec2(0, 0), false);
        if (active_tab == 0) {
            static bool aimbot_enabled = false;
            static float fov = 15.0f;
            static float smooth = 5.0f;
            ImGui::Text("Aimbot Configuration");
            ImGui::Spacing();
            ImGui::Checkbox("Master Switch", &aimbot_enabled);
            ImGui::Spacing();
            ImGui::SliderFloat("Field of View", &fov, 1.0f, 180.0f, "%.1f deg");
            ImGui::SliderFloat("Smoothing", &smooth, 1.0f, 20.0f, "%.1f");
        } else if (active_tab == 1) {
            static bool esp_box = true;
            static bool esp_lines = false;
            static float colors[3] = { 1.0f, 0.0f, 0.0f };
            ImGui::Text("Overlay Visuals");
            ImGui::Spacing();
            ImGui::Checkbox("Draw Bounding Boxes", &esp_box);
            ImGui::Checkbox("Draw Snaplines", &esp_lines);
            ImGui::Spacing();
            ImGui::ColorEdit3("Enemy Color", colors);
        } else {
            ImGui::Text("System Options");
            ImGui::Spacing();
            if (ImGui::Button("Eject Module", ImVec2(150, 40))) glfwSetWindowShouldClose(window, true);
        }
        ImGui::EndChild();

        ImGui::End();
        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        glfwSwapBuffers(window);
    }

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glfwDestroyWindow(window);
    glfwTerminate();
}
