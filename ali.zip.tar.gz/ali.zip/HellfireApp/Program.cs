using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;

namespace Hellfire
{
    class Program
    {
        [DllImport("hellfire", EntryPoint = "RunHellfireMenu", CallingConvention = CallingConvention.Cdecl)]
        private static extern void RunHellfireMenu();

        static void Main(string[] args)
        {
            Console.WriteLine("[*] Injecting payload...");
            Console.WriteLine("[*] Waking the nest...");
            
            // On Linux, .NET looks for libhellfire.so when we specify "hellfire"
            Thread renderThread = new Thread(() => 
            {
                try {
                    RunHellfireMenu();
                } catch (Exception e) {
                    Console.WriteLine("[!] Render thread crashed: " + e.Message);
                }
            });
            
            renderThread.Start();
            
            // C# Logic loop runs here independently of the rendering thread
            while (renderThread.IsAlive)
            {
                Thread.Sleep(100);
            }
            
            Console.WriteLine("[*] Wire cut. Ejected.");
        }
    }
}
