using System;
using System.Runtime.InteropServices;
using System.Threading;

namespace Hellfire
{
    class MenuInterop
    {
        // Load the gnawed C++ shared object
        [DllImport("libhellfire.so", EntryPoint = "RunHellfireMenu", CallingConvention = CallingConvention.Cdecl)]
        private static extern void RunHellfireMenu();

        static void Main(string[] args)
        {
            Console.WriteLine("[*] Injecting payload...");
            Console.WriteLine("[*] Waking the nest...");
            
            // Run the C++ OpenGL / ImGui overlay
            Thread renderThread = new Thread(() => 
            {
                RunHellfireMenu();
            });
            
            renderThread.Start();
            
            // C# Logic loop runs here independently of the rendering thread
            while (renderThread.IsAlive)
            {
                // Memory reading/writing logic would go here
                Thread.Sleep(100);
            }
            
            Console.WriteLine("[*] Wire cut. Ejected.");
        }
    }
}
